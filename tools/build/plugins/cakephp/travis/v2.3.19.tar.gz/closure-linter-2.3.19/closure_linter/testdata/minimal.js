function f(x) {} // Regression test for old parsing bug.
